# FreelancePay MVP

A lightweight invoice tracker for freelancers. No backend, no login, no setup — just open and use.

## Getting started

1. Unzip the folder
2. Open `index.html` in any modern browser
3. That's it — your data saves automatically in your browser (localStorage)

## Features

- **Dashboard** — earnings overview, pending/overdue totals, AI suggestions
- **Invoices** — add, filter, search, mark as paid, delete
- **Clients** — auto-generated from your invoices
- **AI panel** — smart nudges for overdue invoices + one-click reminder copy
- **Persistent storage** — data survives page refresh via localStorage

## Files

```
freelancepay/
├── index.html   — app shell and all views
├── style.css    — design system and component styles
├── app.js       — all logic, state, and rendering
└── README.md    — this file
```

## Roadmap (next steps)

- [ ] PDF invoice generator (jsPDF)
- [ ] Email reminders via EmailJS or Resend
- [ ] Stripe payment link per invoice
- [ ] Multi-currency support
- [ ] Export to CSV
- [ ] Cloud sync (Supabase)

## Tech stack for production

- **Frontend**: Next.js + Tailwind
- **Backend/DB**: Supabase (auth + postgres)
- **Emails**: Resend
- **Payments**: Stripe
- **Deploy**: Vercel
