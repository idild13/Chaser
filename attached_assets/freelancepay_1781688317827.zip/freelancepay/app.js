// ── DATA ──────────────────────────────────────────────────────────
const COLORS = [
  { bg: '#EEEDFE', color: '#3C3489' },
  { bg: '#E1F5EE', color: '#085041' },
  { bg: '#FAEEDA', color: '#633806' },
  { bg: '#FBEAF0', color: '#72243E' },
  { bg: '#E6F1FB', color: '#0C447C' },
  { bg: '#EAF3DE', color: '#27500A' },
];

let invoices = JSON.parse(localStorage.getItem('fp_invoices') || 'null') || [
  { id: 1, client: 'Müller Design',  invnum: 'INV-001', amount: 2400, due: '2026-06-01', desc: 'Brand identity package', status: 'paid' },
  { id: 2, client: 'TechStart GmbH', invnum: 'INV-002', amount: 1800, due: '2026-06-10', desc: 'Landing page development', status: 'overdue' },
  { id: 3, client: 'Bright Agency',  invnum: 'INV-003', amount: 950,  due: '2026-06-25', desc: 'Social media graphics', status: 'pending' },
];
let nextId = Math.max(...invoices.map(i => i.id), 0) + 1;
let activeFilter = 'all';
let searchQuery = '';

function save() {
  localStorage.setItem('fp_invoices', JSON.stringify(invoices));
}

// ── UTILS ─────────────────────────────────────────────────────────
function initials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function colorFor(name) {
  let h = 0;
  for (const c of name) h = (h + c.charCodeAt(0)) % COLORS.length;
  return COLORS[h];
}

function fmt(n) {
  return '€' + Number(n).toLocaleString('de-DE');
}

function daysUntil(dateStr) {
  return Math.round((new Date(dateStr) - new Date()) / 86400000);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

// ── NAVIGATION ────────────────────────────────────────────────────
function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  document.getElementById('view-' + name).classList.add('active');
  document.querySelectorAll('.nav-link').forEach(l => {
    if (l.getAttribute('onclick') && l.getAttribute('onclick').includes(name)) {
      l.classList.add('active');
    }
  });
  if (name === 'invoices') renderTable();
  if (name === 'clients') renderClients();
}

// ── METRICS ───────────────────────────────────────────────────────
function calcMetrics() {
  let earned = 0, pending = 0, overdue = 0, paidCount = 0, pendingCount = 0, overdueCount = 0;
  invoices.forEach(inv => {
    if (inv.status === 'paid')    { earned  += inv.amount; paidCount++; }
    if (inv.status === 'pending') { pending += inv.amount; pendingCount++; }
    if (inv.status === 'overdue') { overdue += inv.amount; overdueCount++; }
  });

  document.getElementById('m-earned').textContent  = fmt(earned);
  document.getElementById('m-pending').textContent = fmt(pending);
  document.getElementById('m-overdue').textContent = fmt(overdue);
  document.getElementById('m-pending-count').textContent = pendingCount + ' invoice' + (pendingCount !== 1 ? 's' : '');
  document.getElementById('m-overdue-count').textContent = overdueCount + ' invoice' + (overdueCount !== 1 ? 's' : '');
  document.getElementById('m-avgdays').textContent = paidCount > 0 ? '~14' : '—';
}

// ── RECENT INVOICES (dashboard) ───────────────────────────────────
function renderRecent() {
  const el = document.getElementById('recent-list');
  const recent = [...invoices].slice(-4).reverse();
  if (!recent.length) {
    el.innerHTML = '<p style="color:#9B9990;font-size:13px;padding:0.5rem 0;">No invoices yet. Add your first one!</p>';
    return;
  }
  el.innerHTML = recent.map(inv => {
    const col = colorFor(inv.client);
    return `<div class="inv-row">
      <div class="avatar" style="background:${col.bg};color:${col.color}">${initials(inv.client)}</div>
      <div>
        <div class="inv-name">${inv.client}</div>
        <div class="inv-meta">${inv.invnum} · Due ${inv.due}</div>
      </div>
      <span class="badge badge-${inv.status}" style="margin-left:auto;margin-right:12px">${inv.status}</span>
      <div class="inv-amount">${fmt(inv.amount)}</div>
    </div>`;
  }).join('');
}

// ── AI PANEL ──────────────────────────────────────────────────────
function renderAI() {
  const el = document.getElementById('ai-panel');
  const overdue  = invoices.filter(i => i.status === 'overdue');
  const pending  = invoices.filter(i => i.status === 'pending');
  let html = '';

  if (!overdue.length && !pending.length) {
    html = `<div class="ai-item">✅ <strong>All clear!</strong> Every invoice is settled. Time to land the next client.</div>`;
  }

  overdue.forEach(inv => {
    const days = Math.abs(daysUntil(inv.due));
    html += `<div class="ai-item">
      🚨 <strong>${inv.client}</strong> is ${days} day${days !== 1 ? 's' : ''} overdue for ${fmt(inv.amount)}.
      Send a reminder to recover this payment fast.
      <br><button class="ai-btn" onclick="markPaid(${inv.id})">✓ Mark as paid</button>
      <button class="ai-btn" onclick="copyReminder('${inv.client}', '${inv.invnum}', ${inv.amount}, ${days})">📋 Copy reminder</button>
    </div>`;
  });

  pending.forEach(inv => {
    const days = daysUntil(inv.due);
    const urgency = days <= 3 ? '⚠️' : '📅';
    html += `<div class="ai-item">
      ${urgency} <strong>${inv.client}</strong> — ${fmt(inv.amount)} due in ${days > 0 ? days + ' day' + (days !== 1 ? 's' : '') : 'today'}.
      <br><button class="ai-btn" onclick="markPaid(${inv.id})">✓ Mark as paid</button>
    </div>`;
  });

  el.innerHTML = html;
}

function copyReminder(client, invnum, amount, days) {
  const text = `Subject: Payment reminder — ${invnum}\n\nHi,\n\nI hope this message finds you well. I wanted to follow up on invoice ${invnum} for ${fmt(amount)}, which was due ${days} day${days !== 1 ? 's' : ''} ago.\n\nCould you let me know when we can expect the payment? Please don't hesitate to reach out if you have any questions.\n\nBest regards`;
  navigator.clipboard.writeText(text).then(() => showToast('Reminder copied to clipboard!')).catch(() => showToast('Copy failed — please try manually.'));
}

// ── TABLE (invoices view) ─────────────────────────────────────────
function setFilter(f, btn) {
  activeFilter = f;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderTable();
}

function setSearch(q) {
  searchQuery = q.toLowerCase();
  renderTable();
}

function renderTable() {
  let data = invoices;
  if (activeFilter !== 'all') data = data.filter(i => i.status === activeFilter);
  if (searchQuery) data = data.filter(i => i.client.toLowerCase().includes(searchQuery));

  const tbody = document.getElementById('inv-tbody');
  const empty = document.getElementById('empty-state');

  if (!data.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  tbody.innerHTML = data.map(inv => {
    const col = colorFor(inv.client);
    return `<tr>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="avatar" style="background:${col.bg};color:${col.color};width:30px;height:30px;font-size:11px">${initials(inv.client)}</div>
          <div>
            <div style="font-weight:500">${inv.client}</div>
            <div style="font-size:11px;color:#9B9990">${inv.desc || ''}</div>
          </div>
        </div>
      </td>
      <td style="color:#5F5E5A">${inv.invnum}</td>
      <td style="font-weight:600">${fmt(inv.amount)}</td>
      <td style="color:#5F5E5A">${inv.due}</td>
      <td><span class="badge badge-${inv.status}">${inv.status}</span></td>
      <td>
        ${inv.status !== 'paid' ? `<button class="action-btn pay" onclick="markPaid(${inv.id})">Mark paid</button>` : ''}
        <button class="action-btn del" onclick="deleteInvoice(${inv.id})">Delete</button>
      </td>
    </tr>`;
  }).join('');
}

// ── CLIENTS VIEW ──────────────────────────────────────────────────
function renderClients() {
  const map = {};
  invoices.forEach(inv => {
    if (!map[inv.client]) map[inv.client] = { total: 0, count: 0, paid: 0 };
    map[inv.client].total += inv.amount;
    map[inv.client].count++;
    if (inv.status === 'paid') map[inv.client].paid += inv.amount;
  });

  const el = document.getElementById('client-grid');
  const clients = Object.entries(map);

  if (!clients.length) {
    el.innerHTML = '<p style="color:#9B9990;font-size:14px">No clients yet. Add your first invoice.</p>';
    return;
  }

  el.innerHTML = clients.map(([name, data]) => {
    const col = colorFor(name);
    return `<div class="client-card">
      <div class="avatar" style="background:${col.bg};color:${col.color}">${initials(name)}</div>
      <div class="client-name">${name}</div>
      <div class="client-stat">${data.count} invoice${data.count !== 1 ? 's' : ''}</div>
      <div class="client-total">${fmt(data.paid)} received</div>
      ${data.total - data.paid > 0 ? `<div style="font-size:12px;color:#854F0B;margin-top:2px">${fmt(data.total - data.paid)} outstanding</div>` : ''}
    </div>`;
  }).join('');
}

// ── ACTIONS ───────────────────────────────────────────────────────
function markPaid(id) {
  const inv = invoices.find(i => i.id === id);
  if (inv) { inv.status = 'paid'; save(); refresh(); showToast(`${inv.client} marked as paid 🎉`); }
}

function deleteInvoice(id) {
  const inv = invoices.find(i => i.id === id);
  if (!inv) return;
  if (!confirm(`Delete invoice ${inv.invnum} for ${inv.client}?`)) return;
  invoices = invoices.filter(i => i.id !== id);
  save(); refresh();
  showToast('Invoice deleted.');
}

// ── MODAL ─────────────────────────────────────────────────────────
function openModal() {
  const today = new Date();
  const def = new Date(today.setDate(today.getDate() + 30)).toISOString().split('T')[0];
  document.getElementById('inp-due').value = def;
  document.getElementById('inp-client').value = '';
  document.getElementById('inp-amount').value = '';
  document.getElementById('inp-desc').value = '';
  document.getElementById('inp-status').value = 'pending';
  document.getElementById('inp-invnum').value = 'INV-' + String(nextId).padStart(3, '0');
  document.getElementById('modal').classList.add('open');
  setTimeout(() => document.getElementById('inp-client').focus(), 50);
}

function closeModal() { document.getElementById('modal').classList.remove('open'); }

function closeModalOutside(e) {
  if (e.target === document.getElementById('modal')) closeModal();
}

function addInvoice() {
  const client = document.getElementById('inp-client').value.trim();
  const amount = parseFloat(document.getElementById('inp-amount').value);
  const due    = document.getElementById('inp-due').value;
  const status = document.getElementById('inp-status').value;
  const desc   = document.getElementById('inp-desc').value.trim();
  const invnum = document.getElementById('inp-invnum').value.trim() || 'INV-' + String(nextId).padStart(3, '0');

  if (!client) { showToast('Please enter a client name.'); return; }
  if (!amount || amount <= 0) { showToast('Please enter a valid amount.'); return; }
  if (!due) { showToast('Please pick a due date.'); return; }

  invoices.push({ id: nextId++, client, invnum, amount, due, desc, status });
  save(); closeModal(); refresh();
  showToast('Invoice added!');
}

// keyboard shortcut — Escape closes modal
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

// ── REFRESH ALL ───────────────────────────────────────────────────
function refresh() {
  calcMetrics();
  renderRecent();
  renderAI();
  renderTable();
}

refresh();
